// frontend/src/pages/TournamentSchedule.tsx
// Strona obsługuje harmonogram turnieju dla meczów par oraz harmonogram etapów i grup w trybie MASS_START.

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";

import { Calendar, Clock, Eraser, Layers3, MapPin } from "lucide-react";

import { apiFetch } from "../api";
import { useTournamentWs } from "../hooks/useTournamentWs";
import { cn } from "../lib/cn";

import { Card } from "../ui/Card";
import { Input } from "../ui/Input";
import { toast } from "../ui/Toast";

import AutosaveIndicator from "../components/AutosaveIndicator";
import { useAutosave } from "../hooks/useAutosave";

import {
  bucketForStatus,
  sectionCardClasses,
  TournamentMatchesScaffold,
  type MatchLikeBase,
  type MatchStatusBucket,
  type StageType,
} from "./_shared/TournamentMatchesScaffold";

// ===== Typy domenowe (harmonogram) =====

type ScheduleStageDTO = {
  stage_id: number;
  stage_type: StageType | "MASS_START";
  stage_order: number;
  stage_name: string;
  scheduled_date: string | null;
  scheduled_time: string | null;
  location: string | null;
};

type ScheduleGroupDTO = {
  group_id: number;
  group_name: string;
  stage_id: number;
  stage_order: number;
  stage_name: string;
  scheduled_date: string | null;
  scheduled_time: string | null;
  location: string | null;
};

type TournamentScheduleDTO = {
  id: number;
  discipline?: string | null;
  competition_model?: string | null;
  start_date: string | null;
  end_date: string | null;
  location: string | null;
  tournament_format?: string | null;
  schedule_targets?: {
    stages: ScheduleStageDTO[];
    groups: ScheduleGroupDTO[];
  };
};

type MatchScheduleDTO = MatchLikeBase & {
  stage_type: StageType;

  round_number: number | null;

  scheduled_date: string | null;
  scheduled_time: string | null;
  location: string | null;
};

type MatchDraft = {
  scheduled_date: string | null;
  scheduled_time: string | null;
  location: string | null;
};

type TournamentMetaDraft = {
  start_date: string | null;
  end_date: string | null;
  location: string | null;
  stage_schedule: ScheduleStageDTO[];
  group_schedule: ScheduleGroupDTO[];
};

// ===== Walidacja i mapowania =====

function isIsoDateBetween(value: string, min: string | null, max: string | null) {
  if (!value) return { ok: true as const };
  if (min && value < min) return { ok: false as const, message: "Data przed startem turnieju." };
  if (max && value > max) return { ok: false as const, message: "Data po zakończeniu turnieju." };
  return { ok: true as const };
}

function validateTournamentDates(start_date: string | null, end_date: string | null) {
  if (!start_date || !end_date) return { ok: true as const };
  if (start_date > end_date) return { ok: false as const, message: "Start po zakończeniu." };
  return { ok: true as const };
}

function toDraft(m: MatchScheduleDTO): MatchDraft {
  return {
    scheduled_date: m.scheduled_date ?? null,
    scheduled_time: m.scheduled_time ?? null,
    location: m.location ?? null,
  };
}

function toMetaDraft(t: TournamentScheduleDTO | null): TournamentMetaDraft | null {
  if (!t) return null;
  return {
    start_date: t.start_date ?? null,
    end_date: t.end_date ?? null,
    location: t.location ?? null,
    stage_schedule: t.schedule_targets?.stages ?? [],
    group_schedule: t.schedule_targets?.groups ?? [],
  };
}

function normalizeMatches(raw: any): MatchScheduleDTO[] {
  if (Array.isArray(raw)) return raw as MatchScheduleDTO[];
  if (Array.isArray(raw?.results)) return raw.results as MatchScheduleDTO[];
  return [];
}

// ===== Strona =====

export default function TournamentSchedule() {
  const { id } = useParams<{ id: string }>();
  const tournamentId = id ?? "";

  const [tournament, setTournament] = useState<TournamentScheduleDTO | null>(null);
  const [matches, setMatches] = useState<MatchScheduleDTO[]>([]);
  const [loading, setLoading] = useState(true);

  // ===== Autosave (synchronizacja zmian z backendem) =====

  const matchAutosave = useAutosave<MatchDraft>({
    onSave: async (matchId, data) => {
      const res = await apiFetch(`/api/matches/${matchId}/`, {
        method: "PATCH",
        toastOnError: false,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const json = await res.json().catch(() => null);
        throw new Error(json?.detail || "Błąd zapisu meczu");
      }

      setMatches((prev) => prev.map((m) => (m.id === matchId ? { ...m, ...data } : m)));
    },
  });

  const tournamentAutosave = useAutosave<TournamentMetaDraft>({
    onSave: async (_key, data) => {
      const datesCheck = validateTournamentDates(data.start_date, data.end_date);
      if (!datesCheck.ok) throw new Error(datesCheck.message);

      const res = await apiFetch(`/api/tournaments/${tournamentId}/meta/`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          start_date: data.start_date,
          end_date: data.end_date,
          location: data.location,
          stage_schedule: data.stage_schedule,
          group_schedule: data.group_schedule,
        }),
      });

      if (!res.ok) {
        const json = await res.json().catch(() => null);
        throw new Error(json?.detail || "Błąd zapisu danych turnieju");
      }

      const payload = (await res.json().catch(() => null)) as TournamentScheduleDTO | null;
      if (payload) {
        setTournament(payload);
      } else {
        setTournament((prev) =>
          prev
            ? {
                ...prev,
                start_date: data.start_date,
                end_date: data.end_date,
                location: data.location,
                schedule_targets: {
                  stages: data.stage_schedule,
                  groups: data.group_schedule,
                },
              }
            : prev
        );
      }
    },
  });

  // ===== Pobieranie danych =====

  useEffect(() => {
    if (!tournamentId) return;

    let alive = true;

    const init = async () => {
      try {
        setLoading(true);

        const [tRes, mRes] = await Promise.all([
          apiFetch(`/api/tournaments/${tournamentId}/`),
          apiFetch(`/api/tournaments/${tournamentId}/matches/`),
        ]);

        if (!tRes.ok || !mRes.ok) throw new Error("Błąd ładowania danych.");

        const tData = (await tRes.json()) as TournamentScheduleDTO;
        const raw = await mRes.json();

        if (!alive) return;

        setTournament(tData);
        setMatches(normalizeMatches(raw));
      } catch {
        toast.error("Wystąpił błąd podczas ładowania.");
      } finally {
        if (alive) setLoading(false);
      }
    };

    void init();
    return () => {
      alive = false;
    };
  }, [tournamentId]);

  const reloadMatches = useCallback(async () => {
    if (!tournamentId) return;
    try {
      const [tRes, mRes] = await Promise.all([
        apiFetch(`/api/tournaments/${tournamentId}/`),
        apiFetch(`/api/tournaments/${tournamentId}/matches/`),
      ]);

      if (tRes.ok) {
        const tData = (await tRes.json()) as TournamentScheduleDTO;
        setTournament(tData);
      }

      if (mRes.ok) {
        const raw = await mRes.json();
        setMatches(normalizeMatches(raw));
      }
    } catch (e: any) {
      toast.error(e?.message || "Nie udało się odświeżyć danych");
    }
  }, [tournamentId]);

  const reloadTimerRef = useRef<number | null>(null);

  const requestMatchesReload = useCallback(() => {
    if (reloadTimerRef.current) return;
    reloadTimerRef.current = window.setTimeout(() => {
      reloadTimerRef.current = null;
      void reloadMatches();
    }, 200);
  }, [reloadMatches]);

  useTournamentWs({
    tournamentId,
    enabled: Boolean(tournamentId),
    onEvent: ({ event }) => {
      const normalized = String(event).replaceAll(".", "_");

      if (normalized === "matches_changed" || normalized === "tournament_changed") {
        requestMatchesReload();
      }
    },
  });

  const tournamentFormat = useMemo(
    () => String(tournament?.tournament_format ?? ""),
    [tournament?.tournament_format]
  );

  const isMassStartScheduleMode = useMemo(() => {
    return (
      String(tournament?.discipline ?? "").toLowerCase() === "custom" &&
      String(tournament?.competition_model ?? "").toUpperCase() === "MASS_START"
    );
  }, [tournament?.competition_model, tournament?.discipline]);

  const currentMeta = (tournamentAutosave.drafts["meta"] ?? toMetaDraft(tournament)) as TournamentMetaDraft | null;
  const metaStatus = tournamentAutosave.statuses["meta"] ?? "idle";

  const fieldWrap =
    "relative flex min-w-0 items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] px-3 h-10";
  const fieldIcon = "h-4 w-4 text-slate-200/90 shrink-0";
  const fieldInput = cn(
    "h-10 w-full min-w-0 bg-transparent text-sm text-slate-100",
    "focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-white/10"
  );

  const updateMetaDraft = useCallback(
    (patch: Partial<TournamentMetaDraft>) => {
      if (!currentMeta) return;
      tournamentAutosave.update("meta", {
        ...currentMeta,
        ...patch,
      });
    },
    [currentMeta, tournamentAutosave]
  );

  const updateStageSchedule = useCallback(
    (stageId: number, patch: Partial<ScheduleStageDTO>) => {
      if (!currentMeta) return;
      updateMetaDraft({
        stage_schedule: currentMeta.stage_schedule.map((stage) =>
          stage.stage_id === stageId ? { ...stage, ...patch } : stage
        ),
      });
    },
    [currentMeta, updateMetaDraft]
  );

  const updateGroupSchedule = useCallback(
    (groupId: number, patch: Partial<ScheduleGroupDTO>) => {
      if (!currentMeta) return;
      updateMetaDraft({
        group_schedule: currentMeta.group_schedule.map((group) =>
          group.group_id === groupId ? { ...group, ...patch } : group
        ),
      });
    },
    [currentMeta, updateMetaDraft]
  );

  const commitMeta = useCallback(() => {
    if (!currentMeta) return;
    void tournamentAutosave.forceSave("meta", currentMeta);
  }, [currentMeta, tournamentAutosave]);

  const massStartStages = useMemo(() => currentMeta?.stage_schedule ?? [], [currentMeta?.stage_schedule]);
  const massStartGroupsByStage = useMemo(() => {
    const groups = currentMeta?.group_schedule ?? [];
    return groups.reduce<Record<number, ScheduleGroupDTO[]>>((acc, group) => {
      if (!acc[group.stage_id]) acc[group.stage_id] = [];
      acc[group.stage_id].push(group);
      return acc;
    }, {});
  }, [currentMeta?.group_schedule]);

  // ===== Karta meta turnieju =====

  const tournamentMetaCard = tournament ? (
    <Card className="mb-6 w-full max-w-[1400px] p-5 sm:p-6">
      <div className="flex flex-wrap justify-between gap-4">
        <div className="flex items-center gap-2">
          <span className="text-base font-semibold text-white">Dane turnieju</span>
          <AutosaveIndicator status={metaStatus} />
        </div>

        <button
          type="button"
          onClick={() => {
            if (!currentMeta) return;
            void tournamentAutosave.forceSave("meta", {
              ...currentMeta,
              start_date: null,
              end_date: null,
              location: null,
              stage_schedule: currentMeta.stage_schedule.map((stage) => ({
                ...stage,
                scheduled_date: null,
                scheduled_time: null,
                location: null,
              })),
              group_schedule: currentMeta.group_schedule.map((group) => ({
                ...group,
                scheduled_date: null,
                scheduled_time: null,
                location: null,
              })),
            });
          }}
          className="inline-flex items-center gap-2 px-2 py-2 text-xs font-medium text-slate-400 transition-colors hover:text-white disabled:opacity-60"
          title="Wyczyść dane turnieju"
          disabled={!currentMeta}
        >
          <Eraser className="h-4 w-4" />
          <span className="hidden sm:inline">Wyczyść</span>
        </button>
      </div>

      <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className={fieldWrap}>
          <Calendar className={fieldIcon} />
          <Input
            unstyled
            className={cn(fieldInput, "[color-scheme:dark]")}
            type="date"
            name="tournament_start_date"
            aria-label="Data rozpoczęcia turnieju"
            value={currentMeta?.start_date ?? ""}
            max={currentMeta?.end_date ?? undefined}
            onChange={(e) => updateMetaDraft({ start_date: e.target.value || null })}
            onBlur={commitMeta}
          />
        </div>

        <div className={fieldWrap}>
          <Calendar className={fieldIcon} />
          <Input
            unstyled
            className={cn(fieldInput, "[color-scheme:dark]")}
            type="date"
            name="tournament_end_date"
            aria-label="Data zakończenia turnieju"
            value={currentMeta?.end_date ?? ""}
            min={currentMeta?.start_date ?? undefined}
            onChange={(e) => updateMetaDraft({ end_date: e.target.value || null })}
            onBlur={commitMeta}
          />
        </div>

        <div className={fieldWrap}>
          <MapPin className={fieldIcon} />
          <Input
            unstyled
            className={fieldInput}
            name="tournament_location"
            aria-label="Lokalizacja turnieju"
            placeholder="Lokalizacja"
            value={currentMeta?.location ?? ""}
            onChange={(e) => updateMetaDraft({ location: e.target.value || null })}
            onBlur={commitMeta}
          />
        </div>
      </div>

      {tournamentAutosave.errors["meta"] ? (
        <div className="mt-3 text-xs text-rose-300">{tournamentAutosave.errors["meta"]}</div>
      ) : null}
    </Card>
  ) : null;

  // ===== Render karty meczu =====

  const cardShellForMatch = (bucket: MatchStatusBucket, isOutOfRange: boolean) => {
    const base = sectionCardClasses(bucket);

    if (isOutOfRange) {
      return { shell: cn(base.shell, "border-rose-400/25 bg-rose-500/[0.06]") };
    }

    return { shell: cn(base.shell) };
  };

  const stageTitle = (stageType: StageType, allMatchesForStage: MatchScheduleDTO[]) => {
    if (stageType === "LEAGUE") return "Liga - terminarz";
    if (stageType === "GROUP") return "Faza grupowa - terminarz";
    if (stageType === "THIRD_PLACE") return "Mecz o 3 miejsce";

    const matchesCount = allMatchesForStage.length;
    if (matchesCount === 1) return "Finał";
    if (matchesCount === 2) return "Półfinał";
    if (matchesCount === 4) return "Ćwierćfinał";
    return `1/${matchesCount * 2} Finału`;
  };

  const renderMatchRow = (m: MatchScheduleDTO) => {
    const draft = matchAutosave.drafts[m.id] ?? toDraft(m);
    const saveStatus = matchAutosave.statuses[m.id] ?? "idle";
    const error = matchAutosave.errors[m.id] ?? null;

    const dateCheck = draft.scheduled_date
      ? isIsoDateBetween(draft.scheduled_date, tournament?.start_date ?? null, tournament?.end_date ?? null)
      : { ok: true as const };

    const bucket = bucketForStatus(m.status);
    const shell = cardShellForMatch(bucket, !dateCheck.ok);

    const errId = `match-${m.id}-error`;
    const rangeId = `match-${m.id}-range`;

    return (
      <Card key={m.id} className={cn("p-5 sm:p-6 border", shell.shell)}>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <span className="min-w-0 truncate">
                {m.home_team_name} <span className="font-normal text-slate-400">vs</span> {m.away_team_name}
              </span>
              <AutosaveIndicator status={saveStatus} error={error} />
            </div>

            {error ? (
              <div id={errId} className="mt-1 text-xs text-rose-300">
                {error}
              </div>
            ) : null}

            {!dateCheck.ok ? (
              <div id={rangeId} className="mt-1 text-xs text-rose-300">
                {dateCheck.message}
              </div>
            ) : null}
          </div>

          <button
            type="button"
            onClick={() => {
              void matchAutosave.forceSave(m.id, {
                scheduled_date: null,
                scheduled_time: null,
                location: null,
              });
            }}
            className="inline-flex items-center gap-2 px-2 py-2 text-xs font-medium text-slate-400 transition-colors hover:text-white"
            title="Wyczyść dane meczu"
          >
            <Eraser className="h-4 w-4" />
            <span className="hidden sm:inline">Wyczyść</span>
          </button>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
          <div className={fieldWrap}>
            <Calendar className={fieldIcon} />
            <Input
              unstyled
              className={cn(fieldInput, "[color-scheme:dark]")}
              type="date"
              name={`match_${m.id}_scheduled_date`}
              aria-label="Data meczu"
              aria-describedby={cn(error ? errId : "", !dateCheck.ok ? rangeId : "").trim() || undefined}
              value={draft.scheduled_date ?? ""}
              min={tournament?.start_date ?? undefined}
              max={tournament?.end_date ?? undefined}
              onChange={(e) => matchAutosave.update(m.id, { ...draft, scheduled_date: e.target.value || null })}
              onBlur={() => void matchAutosave.forceSave(m.id, draft)}
            />
          </div>

          <div className={fieldWrap}>
            <Clock className={fieldIcon} />
            <Input
              unstyled
              className={cn(fieldInput, "[color-scheme:dark]")}
              type="time"
              name={`match_${m.id}_scheduled_time`}
              aria-label="Godzina meczu"
              aria-describedby={error ? errId : undefined}
              value={draft.scheduled_time ?? ""}
              onChange={(e) => matchAutosave.update(m.id, { ...draft, scheduled_time: e.target.value || null })}
              onBlur={() => void matchAutosave.forceSave(m.id, draft)}
            />
          </div>

          <div className={fieldWrap}>
            <MapPin className={fieldIcon} />
            <Input
              unstyled
              className={fieldInput}
              name={`match_${m.id}_location`}
              aria-label="Miejsce meczu"
              aria-describedby={error ? errId : undefined}
              placeholder="Miejsce"
              value={draft.location ?? ""}
              onChange={(e) => matchAutosave.update(m.id, { ...draft, location: e.target.value || null })}
              onBlur={() => void matchAutosave.forceSave(m.id, draft)}
            />
          </div>
        </div>
      </Card>
    );
  };

  const renderMassStartSchedule = () => (
    <div className="w-full py-6">
      {tournamentMetaCard}

      <Card className="w-full max-w-[1400px] p-5 sm:p-6">
        <div className="flex items-center gap-2">
          <Layers3 className="h-4 w-4 text-white/80" />
          <div>
            <div className="text-base font-semibold text-white">Harmonogram etapów i grup</div>
            <div className="text-sm text-slate-300">
              W trybie „wszyscy razem” harmonogram jest planowany na poziomie etapu i grup w etapie.
            </div>
          </div>
        </div>

        <div className="mt-5 space-y-5">
          {massStartStages.map((stage) => {
            const stageGroups = (massStartGroupsByStage[stage.stage_id] ?? []).sort((a, b) =>
              a.group_name.localeCompare(b.group_name, "pl")
            );
            const stageDateCheck = stage.scheduled_date
              ? isIsoDateBetween(stage.scheduled_date, tournament?.start_date ?? null, tournament?.end_date ?? null)
              : { ok: true as const };

            return (
              <div key={stage.stage_id} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                <div className="mb-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-white">{stage.stage_name}</div>
                    <div className="text-xs text-slate-400">
                      Etap {stage.stage_order}
                    </div>
                    {!stageDateCheck.ok ? (
                      <div className="mt-1 text-xs text-rose-300">{stageDateCheck.message}</div>
                    ) : null}
                  </div>
                  <AutosaveIndicator status={metaStatus} error={tournamentAutosave.errors["meta"] ?? undefined} />
                </div>

                <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                  <div className={fieldWrap}>
                    <Calendar className={fieldIcon} />
                    <Input
                      unstyled
                      className={cn(fieldInput, "[color-scheme:dark]")}
                      type="date"
                      value={stage.scheduled_date ?? ""}
                      min={tournament?.start_date ?? undefined}
                      max={tournament?.end_date ?? undefined}
                      onChange={(e) => updateStageSchedule(stage.stage_id, { scheduled_date: e.target.value || null })}
                      onBlur={commitMeta}
                      aria-label={`Data dla ${stage.stage_name}`}
                    />
                  </div>

                  <div className={fieldWrap}>
                    <Clock className={fieldIcon} />
                    <Input
                      unstyled
                      className={cn(fieldInput, "[color-scheme:dark]")}
                      type="time"
                      value={stage.scheduled_time ?? ""}
                      onChange={(e) => updateStageSchedule(stage.stage_id, { scheduled_time: e.target.value || null })}
                      onBlur={commitMeta}
                      aria-label={`Godzina dla ${stage.stage_name}`}
                    />
                  </div>

                  <div className={fieldWrap}>
                    <MapPin className={fieldIcon} />
                    <Input
                      unstyled
                      className={fieldInput}
                      value={stage.location ?? ""}
                      placeholder="Lokalizacja etapu"
                      onChange={(e) => updateStageSchedule(stage.stage_id, { location: e.target.value || null })}
                      onBlur={commitMeta}
                      aria-label={`Lokalizacja dla ${stage.stage_name}`}
                    />
                  </div>
                </div>

                {stageGroups.length ? (
                  <div className="mt-4 space-y-3">
                    {stageGroups.map((group) => {
                      const groupDateCheck = group.scheduled_date
                        ? isIsoDateBetween(group.scheduled_date, tournament?.start_date ?? null, tournament?.end_date ?? null)
                        : { ok: true as const };

                      return (
                        <div
                          key={group.group_id}
                          className="rounded-2xl border border-white/10 bg-black/10 p-4"
                        >
                          <div className="mb-3">
                            <div className="text-sm font-semibold text-white">{group.group_name}</div>
                            {!groupDateCheck.ok ? (
                              <div className="mt-1 text-xs text-rose-300">{groupDateCheck.message}</div>
                            ) : null}
                          </div>

                          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                            <div className={fieldWrap}>
                              <Calendar className={fieldIcon} />
                              <Input
                                unstyled
                                className={cn(fieldInput, "[color-scheme:dark]")}
                                type="date"
                                value={group.scheduled_date ?? ""}
                                min={tournament?.start_date ?? undefined}
                                max={tournament?.end_date ?? undefined}
                                onChange={(e) =>
                                  updateGroupSchedule(group.group_id, {
                                    scheduled_date: e.target.value || null,
                                  })
                                }
                                onBlur={commitMeta}
                                aria-label={`Data dla ${group.group_name}`}
                              />
                            </div>

                            <div className={fieldWrap}>
                              <Clock className={fieldIcon} />
                              <Input
                                unstyled
                                className={cn(fieldInput, "[color-scheme:dark]")}
                                type="time"
                                value={group.scheduled_time ?? ""}
                                onChange={(e) =>
                                  updateGroupSchedule(group.group_id, {
                                    scheduled_time: e.target.value || null,
                                  })
                                }
                                onBlur={commitMeta}
                                aria-label={`Godzina dla ${group.group_name}`}
                              />
                            </div>

                            <div className={fieldWrap}>
                              <MapPin className={fieldIcon} />
                              <Input
                                unstyled
                                className={fieldInput}
                                value={group.location ?? ""}
                                placeholder="Lokalizacja grupy"
                                onChange={(e) =>
                                  updateGroupSchedule(group.group_id, {
                                    location: e.target.value || null,
                                  })
                                }
                                onBlur={commitMeta}
                                aria-label={`Lokalizacja dla ${group.group_name}`}
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>

        {tournamentAutosave.errors["meta"] ? (
          <div className="mt-4 text-xs text-rose-300">{tournamentAutosave.errors["meta"]}</div>
        ) : null}
      </Card>
    </div>
  );

  // ===== Widok =====

  if (!tournamentId) {
    return (
      <div className="w-full py-6">
        <Card className="p-6 text-slate-200">Brak ID turnieju.</Card>
      </div>
    );
  }

  if (!loading && !tournament) {
    return (
      <div className="w-full py-6">
        <Card className="p-6 text-slate-200">Nie znaleziono turnieju.</Card>
      </div>
    );
  }

  if (isMassStartScheduleMode) {
    return renderMassStartSchedule();
  }

  return (
    <TournamentMatchesScaffold
      tournamentId={tournamentId}
      tournamentFormat={tournamentFormat}
      title="Harmonogram i lokalizacja"
      description="Ustaw termin i lokalizację turnieju, a następnie doprecyzuj datę, godzinę i miejsce dla każdego meczu."
      loading={loading}
      matches={matches}
      headerSlot={tournamentMetaCard}
      storageScope="schedule"
      renderMatch={renderMatchRow}
      stageTitle={stageTitle}
    />
  );
}
