// frontend/src/pages/Account.tsx
// Plik prezentuje ustawienia konta użytkownika oraz inicjuje przepływy zmiany danych wrażliwych.

import { useCallback, useEffect, useMemo, useState } from "react";

import { apiFetch } from "../api";
import { cn } from "../lib/cn";

import { Button } from "../ui/Button";
import { Card } from "../ui/Card";
import { Input } from "../ui/Input";
import { InlineAlert } from "../ui/InlineAlert";
import { toast } from "../ui/Toast";

type MeDTO = {
  id?: number;
  username?: string | null;
  email?: string | null;
  email_verified?: boolean | null;
  created_at?: string | null;
};

type FormState = {
  pending: boolean;
  message?: { variant: "info" | "success" | "danger"; title?: string; text: string };
};

function mapApiErrorToText(e: unknown) {
  if (!e) return "Wystąpił nieoczekiwany błąd.";
  if (typeof e === "string") return e;
  return "Nie udało się wykonać operacji.";
}

export default function Account() {
  const [me, setMe] = useState<MeDTO | null>(null);
  const [loading, setLoading] = useState(true);

  const [usernameForm, setUsernameForm] = useState({ newUsername: "", currentPassword: "" });
  const [emailForm, setEmailForm] = useState({ newEmail: "", currentPassword: "" });
  const [passwordForm, setPasswordForm] = useState({ currentPassword: "", newPassword: "" });

  const [usernameState, setUsernameState] = useState<FormState>({ pending: false });
  const [emailState, setEmailState] = useState<FormState>({ pending: false });
  const [passwordState, setPasswordState] = useState<FormState>({ pending: false });

  const accountSummary = useMemo(() => {
    const username = me?.username ?? "";
    const email = me?.email ?? "";

    const emailVerified =
      me?.email_verified === null || typeof me?.email_verified === "undefined"
        ? null
        : Boolean(me.email_verified);

    return { username, email, emailVerified };
  }, [me]);

  const loadMe = useCallback(async () => {
    setLoading(true);

    try {
      const res = await apiFetch("/api/auth/me/", { method: "GET", toastOnError: false });
      if (!res.ok) {
        setMe(null);
        setLoading(false);
        return;
      }

      const data = (await res.json().catch(() => null)) as MeDTO | null;
      setMe(data);
    } catch {
      setMe(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadMe();
  }, [loadMe]);

  const requestUsernameChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setUsernameState({ pending: true });

    try {
      const res = await apiFetch("/api/account/change-username/", {
        method: "POST",
        toastOnError: false,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          new_username: usernameForm.newUsername.trim(),
          current_password: usernameForm.currentPassword,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => null);
        const detail =
          (data && (data.detail || data.non_field_errors?.[0] || data.new_username?.[0])) || null;

        setUsernameState({
          pending: false,
          message: { variant: "danger", text: detail || "Nie udało się zainicjować zmiany loginu." },
        });
        return;
      }

      setUsernameState({
        pending: false,
        message: {
          variant: "success",
          text: "Wysłano wiadomość e-mail z linkiem potwierdzającym zmianę loginu.",
        },
      });
      toast.success("Wysłano e-mail potwierdzający");
      setUsernameForm({ newUsername: "", currentPassword: "" });
    } catch (err) {
      setUsernameState({
        pending: false,
        message: { variant: "danger", text: mapApiErrorToText(err) },
      });
    }
  };

  const requestEmailChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailState({ pending: true });

    try {
      const res = await apiFetch("/api/account/change-email/", {
        method: "POST",
        toastOnError: false,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          new_email: emailForm.newEmail.trim(),
          current_password: emailForm.currentPassword,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => null);
        const detail =
          (data && (data.detail || data.non_field_errors?.[0] || data.new_email?.[0])) || null;

        setEmailState({
          pending: false,
          message: { variant: "danger", text: detail || "Nie udało się zainicjować zmiany e-mail." },
        });
        return;
      }

      setEmailState({
        pending: false,
        message: {
          variant: "success",
          text: "Wysłano wiadomość e-mail na obecny adres w celu potwierdzenia zmiany.",
        },
      });
      toast.success("Wysłano e-mail potwierdzający");
      setEmailForm({ newEmail: "", currentPassword: "" });
    } catch (err) {
      setEmailState({
        pending: false,
        message: { variant: "danger", text: mapApiErrorToText(err) },
      });
    }
  };

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordState({ pending: true });

    try {
      const res = await apiFetch("/api/account/change-password/", {
        method: "POST",
        toastOnError: false,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          current_password: passwordForm.currentPassword,
          new_password: passwordForm.newPassword,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => null);
        const detail =
          (data &&
            (data.detail ||
              data.non_field_errors?.[0] ||
              data.current_password?.[0] ||
              data.new_password?.[0])) ||
          null;

        setPasswordState({
          pending: false,
          message: { variant: "danger", text: detail || "Nie udało się zmienić hasła." },
        });
        return;
      }

      setPasswordState({
        pending: false,
        message: { variant: "success", text: "Hasło zostało zmienione." },
      });
      toast.success("Hasło zmienione");
      setPasswordForm({ currentPassword: "", newPassword: "" });
    } catch (err) {
      setPasswordState({
        pending: false,
        message: { variant: "danger", text: mapApiErrorToText(err) },
      });
    }
  };

  return (
    <div className="mx-auto w-full max-w-[1100px]">
      <div className="mb-6">
        <div className="text-2xl font-bold text-white">Moje konto</div>
        <div className="mt-1 text-sm text-slate-300">
          Zarządzanie danymi konta i bezpieczeństwem logowania.
        </div>
      </div>

      {loading ? (
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-slate-300">
          Ładowanie danych konta...
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
          <Card className="p-5">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <div className="text-lg font-semibold text-white">Dane konta</div>
                <div className="mt-1 text-sm text-slate-300">Podstawowe informacje o profilu.</div>
              </div>

              <Button variant="secondary" onClick={() => void loadMe()}>
                Odśwież
              </Button>
            </div>

            <div className="space-y-3">
              <div className="rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3">
                <div className="text-xs font-medium uppercase tracking-wider text-slate-400">
                  Login
                </div>
                <div className="mt-1 text-base font-semibold text-white">
                  {accountSummary.username || "Brak danych"}
                </div>
              </div>

              <div className="rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3">
                <div className="text-xs font-medium uppercase tracking-wider text-slate-400">
                  E-mail
                </div>
                <div className="mt-1 text-base font-semibold text-white">
                  {accountSummary.email || "Brak danych"}
                </div>

                {accountSummary.emailVerified !== null ? (
                  <div
                    className={cn(
                      "mt-2 inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium",
                      accountSummary.emailVerified
                        ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-200"
                        : "border-amber-500/30 bg-amber-500/10 text-amber-200"
                    )}
                  >
                    {accountSummary.emailVerified ? "E-mail zweryfikowany" : "E-mail niezweryfikowany"}
                  </div>
                ) : null}
              </div>
            </div>
          </Card>

          <Card className="p-5">
            <div className="mb-3">
              <div className="text-lg font-semibold text-white">Zmiana loginu</div>
              <div className="mt-1 text-sm text-slate-300">
                Zmiana wymaga potwierdzenia przez e-mail na aktualnym adresie.
              </div>
            </div>

            {usernameState.message ? (
              <InlineAlert
                variant={usernameState.message.variant}
                title={usernameState.message.title}
                className="mb-3"
              >
                {usernameState.message.text}
              </InlineAlert>
            ) : null}

            <form onSubmit={requestUsernameChange} className="space-y-3">
              <Input
                label="Nowy login"
                value={usernameForm.newUsername}
                onChange={(e) => setUsernameForm((s) => ({ ...s, newUsername: e.target.value }))}
                autoComplete="username"
                placeholder="np. dawid_k"
                disabled={usernameState.pending}
              />

              <Input
                label="Aktualne hasło"
                type="password"
                value={usernameForm.currentPassword}
                onChange={(e) => setUsernameForm((s) => ({ ...s, currentPassword: e.target.value }))}
                autoComplete="current-password"
                disabled={usernameState.pending}
              />

              <div className="flex justify-end">
                <Button
                  type="submit"
                  variant="primary"
                  loading={usernameState.pending}
                  disabled={!usernameForm.newUsername.trim() || !usernameForm.currentPassword}
                >
                  Wyślij potwierdzenie
                </Button>
              </div>
            </form>
          </Card>

          <Card className="p-5">
            <div className="mb-3">
              <div className="text-lg font-semibold text-white">Zmiana e-mail</div>
              <div className="mt-1 text-sm text-slate-300">
                Zmiana wymaga potwierdzenia na obecnym adresie e-mail.
              </div>
            </div>

            {emailState.message ? (
              <InlineAlert
                variant={emailState.message.variant}
                title={emailState.message.title}
                className="mb-3"
              >
                {emailState.message.text}
              </InlineAlert>
            ) : null}

            <form onSubmit={requestEmailChange} className="space-y-3">
              <Input
                label="Nowy e-mail"
                value={emailForm.newEmail}
                onChange={(e) => setEmailForm((s) => ({ ...s, newEmail: e.target.value }))}
                autoComplete="email"
                placeholder="np. nowy@email.com"
                disabled={emailState.pending}
              />

              <Input
                label="Aktualne hasło"
                type="password"
                value={emailForm.currentPassword}
                onChange={(e) => setEmailForm((s) => ({ ...s, currentPassword: e.target.value }))}
                autoComplete="current-password"
                disabled={emailState.pending}
              />

              <div className="flex justify-end">
                <Button
                  type="submit"
                  variant="primary"
                  loading={emailState.pending}
                  disabled={!emailForm.newEmail.trim() || !emailForm.currentPassword}
                >
                  Wyślij potwierdzenie
                </Button>
              </div>
            </form>
          </Card>

          <Card className="p-5">
            <div className="mb-3">
              <div className="text-lg font-semibold text-white">Zmiana hasła</div>
              <div className="mt-1 text-sm text-slate-300">
                Operacja wymaga podania aktualnego hasła w celu ponownej autoryzacji.
              </div>
            </div>

            {passwordState.message ? (
              <InlineAlert
                variant={passwordState.message.variant}
                title={passwordState.message.title}
                className="mb-3"
              >
                {passwordState.message.text}
              </InlineAlert>
            ) : null}

            <form onSubmit={changePassword} className="space-y-3">
              <Input
                label="Aktualne hasło"
                type="password"
                value={passwordForm.currentPassword}
                onChange={(e) => setPasswordForm((s) => ({ ...s, currentPassword: e.target.value }))}
                autoComplete="current-password"
                disabled={passwordState.pending}
              />

              <Input
                label="Nowe hasło"
                type="password"
                value={passwordForm.newPassword}
                onChange={(e) => setPasswordForm((s) => ({ ...s, newPassword: e.target.value }))}
                autoComplete="new-password"
                disabled={passwordState.pending}
              />

              <div className="flex justify-end">
                <Button
                  type="submit"
                  variant="primary"
                  loading={passwordState.pending}
                  disabled={!passwordForm.currentPassword || !passwordForm.newPassword}
                >
                  Zmień hasło
                </Button>
              </div>
            </form>
          </Card>

          <Card className="p-5 lg:col-span-2">
            <div className="mb-3">
              <div className="text-lg font-semibold text-white">Historia logowań</div>
              <div className="mt-1 text-sm text-slate-300">
                Sekcja wymaga endpointu zwracającego zdarzenia logowania (data, urządzenie, IP).
              </div>
            </div>

            <div className="rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-slate-300">
              Brak danych do wyświetlenia. Po dodaniu API można pokazać ostatnie logowania oraz opcję
              wylogowania z innych urządzeń.
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}