# backend/tournaments/services/standings/compute.py
# Plik oblicza klasyfikację etapu na podstawie zakończonych meczów i reguł dyscypliny.

from __future__ import annotations

from typing import Any, Literal, Tuple

from tournaments.models import Group, Match, Stage, Team, Tournament
from tournaments.services.match_outcome import final_score
from tournaments.services.standings.rulesets.base import StandingsRuleset
from tournaments.services.standings.rulesets.football import FootballPZPNRuleset
from tournaments.services.standings.rulesets.handball import HandballSuperligaRuleset
from tournaments.services.standings.rulesets.tennis import TennisRuleset
from tournaments.services.standings.types import StandingRow

BYE_TEAM_NAME = "__SYSTEM_BYE__"

TennisPointsMode = Literal["NONE", "PLT"]


def _is_custom_result_mode(tournament: Tournament) -> bool:
    return getattr(tournament, "result_mode", Tournament.ResultMode.SCORE) == Tournament.ResultMode.CUSTOM


def _get_ruleset(tournament: Tournament) -> StandingsRuleset:
    discipline = getattr(tournament, "discipline", None)

    if discipline in (Tournament.Discipline.FOOTBALL, "football", "FOOTBALL"):
        return FootballPZPNRuleset()

    if discipline in (Tournament.Discipline.HANDBALL, "handball", "HANDBALL"):
        return HandballSuperligaRuleset()

    if discipline in (Tournament.Discipline.TENNIS, "tennis", "TENNIS"):
        cfg = getattr(tournament, "format_config", None) or {}
        mode = (cfg.get("tennis_points_mode") or "NONE").upper()
        return TennisRuleset(points_mode="PLT" if mode == "PLT" else "NONE")

    # CUSTOM nie ma jeszcze własnego rulesetu, bo etap 1 nie wprowadza modelu rezultatu klasyfikacji.
    return FootballPZPNRuleset()


def compute_stage_standings(
    tournament: Tournament,
    stage: Stage,
    group: Group | None = None,
) -> list[StandingRow]:
    teams = _get_teams_for_context(tournament, stage, group)
    rows = _initialize_rows(teams)

    # Etap 1 dla CUSTOM utrzymuje stabilną listę uczestników bez prób liczenia z wyniku meczowego.
    if _is_custom_result_mode(tournament):
        return _sort_custom_rows(rows.values())

    ruleset = _get_ruleset(tournament)

    finished_matches = list(_get_finished_matches(stage, group))
    all_stage_matches = list(_get_all_matches(stage, group))

    for match in finished_matches:
        _apply_match_result(rows, match, tournament)

    # Różnice są wyliczane po agregacji wszystkich zakończonych spotkań w kontekście etapu.
    for row in rows.values():
        row.goal_difference = row.goals_for - row.goals_against
        row.games_difference = row.games_for - row.games_against

    return ruleset.sort_rows(rows.values(), finished_matches, all_stage_matches)


def _sort_custom_rows(rows) -> list[StandingRow]:
    # Kolejność jest stabilna i przewidywalna do czasu wdrożenia osobnego modelu rezultatu custom.
    return sorted(
        rows,
        key=lambda row: ((row.team_name or "").strip().lower(), row.team_id),
    )


def _get_teams_for_context(
    tournament: Tournament,
    stage: Stage,
    group: Group | None,
) -> list[Team]:
    if group is None:
        return list(tournament.teams.exclude(name=BYE_TEAM_NAME).order_by("id"))

    home_team_ids = set(
        Match.objects.filter(stage=stage, group=group).values_list("home_team_id", flat=True)
    )
    away_team_ids = set(
        Match.objects.filter(stage=stage, group=group).values_list("away_team_id", flat=True)
    )
    team_ids = home_team_ids | away_team_ids

    return list(
        Team.objects.filter(id__in=team_ids).exclude(name=BYE_TEAM_NAME).order_by("id")
    )


def _get_finished_matches(stage: Stage, group: Group | None):
    qs = Match.objects.filter(stage=stage, status=Match.Status.FINISHED)
    if group is not None:
        qs = qs.filter(group=group)
    return qs


def _get_all_matches(stage: Stage, group: Group | None):
    qs = Match.objects.filter(stage=stage)
    if group is not None:
        qs = qs.filter(group=group)
    return qs


def _initialize_rows(teams: list[Team]) -> dict[int, StandingRow]:
    return {team.id: StandingRow(team_id=team.id, team_name=team.name) for team in teams}


def _safe_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _tennis_games_from_match(match: Match) -> Tuple[int, int]:
    sets = getattr(match, "tennis_sets", None)
    if not isinstance(sets, list):
        return (0, 0)

    home_games_sum = 0
    away_games_sum = 0

    for set_item in sets:
        if not isinstance(set_item, dict):
            continue
        home_games_sum += _safe_int(set_item.get("home_games"))
        away_games_sum += _safe_int(set_item.get("away_games"))

    return (home_games_sum, away_games_sum)


def _tennis_points_mode(tournament: Tournament) -> TennisPointsMode:
    cfg = getattr(tournament, "format_config", None) or {}
    mode = (cfg.get("tennis_points_mode") or "NONE").upper()
    return "PLT" if mode == "PLT" else "NONE"


def _plt_points_from_sets(match: Match, home_sets: int, away_sets: int) -> Tuple[int, int]:
    tennis_sets = getattr(match, "tennis_sets", None)

    # Brak danych setowych przy 0:0 jest traktowany defensywnie jako brak punktów.
    if (not tennis_sets) and home_sets == 0 and away_sets == 0:
        return (0, 0)

    if home_sets == away_sets:
        return (0, 0)

    home_won = home_sets > away_sets
    loser_sets = min(home_sets, away_sets)

    if loser_sets == 0:
        return (10, 2) if home_won else (2, 10)

    return (8, 4) if home_won else (4, 8)


def _apply_match_result(
    rows: dict[int, StandingRow],
    match: Match,
    tournament: Tournament,
) -> None:
    home = rows.get(match.home_team_id)
    away = rows.get(match.away_team_id)
    if not home or not away:
        return

    hs, aws = final_score(match)

    home.played += 1
    away.played += 1

    # goals_* przechowuje sety dla tenisa oraz wynik końcowy dla pozostałych dyscyplin.
    home.goals_for += hs
    home.goals_against += aws
    away.goals_for += aws
    away.goals_against += hs

    discipline = getattr(tournament, "discipline", None)
    is_handball = discipline in (
        Tournament.Discipline.HANDBALL,
        "handball",
        "HANDBALL",
    )
    is_tennis = discipline in (
        Tournament.Discipline.TENNIS,
        "tennis",
        "TENNIS",
    )

    if is_tennis:
        home_games, away_games = _tennis_games_from_match(match)
        home.games_for += home_games
        home.games_against += away_games
        away.games_for += away_games
        away.games_against += home_games

        if hs > aws:
            home.wins += 1
            away.losses += 1
        elif hs < aws:
            away.wins += 1
            away.away_wins += 1
            home.losses += 1
        else:
            home.draws += 1
            away.draws += 1
            return

        mode = _tennis_points_mode(tournament)
        if mode == "PLT":
            points_home, points_away = _plt_points_from_sets(match, hs, aws)
            home.points += points_home
            away.points += points_away

        return

    if not is_handball:
        if hs > aws:
            home.wins += 1
            away.losses += 1
            home.points += 3
            return

        if hs < aws:
            away.wins += 1
            away.away_wins += 1
            home.losses += 1
            away.points += 3
            return

        home.draws += 1
        away.draws += 1
        home.points += 1
        away.points += 1
        return

    if hs > aws:
        home.wins += 1
        away.losses += 1
        home.points += 3
        return

    if hs < aws:
        away.wins += 1
        away.away_wins += 1
        home.losses += 1
        away.points += 3
        return

    if (
        match.decided_by_penalties
        and match.home_penalty_score is not None
        and match.away_penalty_score is not None
    ):
        if match.home_penalty_score > match.away_penalty_score:
            home.wins += 1
            home.penalty_wins += 1
            away.losses += 1
            away.penalty_losses += 1
            home.points += 2
            away.points += 1
        elif match.home_penalty_score < match.away_penalty_score:
            away.wins += 1
            away.penalty_wins += 1
            away.away_wins += 1
            home.losses += 1
            home.penalty_losses += 1
            away.points += 2
            home.points += 1
        else:
            home.draws += 1
            away.draws += 1
    else:
        home.draws += 1
        away.draws += 1
        home.points += 1
        away.points += 1