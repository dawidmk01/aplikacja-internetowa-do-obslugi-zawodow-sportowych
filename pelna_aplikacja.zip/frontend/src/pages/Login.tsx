// frontend/src/pages/Login.tsx
// Plik udostępnia formularze logowania i rejestracji oraz inicjuje sesję po udanym logowaniu.

import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Eye, EyeOff, Loader2, Lock, LogIn, Mail, User, UserPlus } from "lucide-react";

import { apiFetch, setAccess } from "../api";
import { cn } from "../lib/cn";

import { Button } from "../ui/Button";
import { Card } from "../ui/Card";
import { InlineAlert } from "../ui/InlineAlert";
import { Input } from "../ui/Input";

type Props = {
  onLogin?: () => Promise<void>;
};

function pickFirstError(data: unknown): string | null {
  if (!data) return null;
  if (typeof data === "string") return data;

  if (typeof data === "object") {
    const record = data as Record<string, unknown>;

    if (typeof record.detail === "string") {
      return record.detail;
    }

    for (const key of ["username", "email", "password", "non_field_errors"]) {
      const value = record[key];
      if (Array.isArray(value) && value.length) {
        return String(value[0]);
      }
    }
  }

  return null;
}

export default function Login({ onLogin }: Props) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const urlMode = searchParams.get("mode");
  const nextParam = searchParams.get("next") || "";

  const [mode, setMode] = useState<"login" | "register">(urlMode === "register" ? "register" : "login");

  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [showPassword, setShowPassword] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    setMode(urlMode === "register" ? "register" : "login");
    setError(null);
  }, [urlMode]);

  const nextQs = useMemo(() => {
    return nextParam && nextParam.startsWith("/") ? `next=${encodeURIComponent(nextParam)}` : "";
  }, [nextParam]);

  const goLogin = () => {
    navigate(nextQs ? `/login?${nextQs}` : "/login");
  };

  const goRegister = () => {
    navigate(nextQs ? `/login?mode=register&${nextQs}` : "/login?mode=register");
  };

  const translateLoginError = (msg?: string) => {
    if (!msg) return "Błąd logowania.";
    if (msg.includes("No active account")) return "Nieprawidłowy login lub hasło.";
    if (msg.toLowerCase().includes("unauthorized")) return "Brak dostępu. Zaloguj się ponownie.";
    return msg;
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      if (mode === "login") {
        const res = await apiFetch("/api/auth/login/", {
          method: "POST",
          body: JSON.stringify({ username, password }),
          toastOnError: false,
        });

        const data = await res.json().catch(() => ({}));

        if (!res.ok) {
          setError(translateLoginError(pickFirstError(data) || (data as Record<string, unknown>)?.detail?.toString()));
          return;
        }

        const access = (data as Record<string, unknown>)?.access;
        if (typeof access === "string" && access.trim()) {
          setAccess(access);
        } else {
          setError("Brak access tokena w odpowiedzi logowania.");
          return;
        }

        await onLogin?.();

        if (nextParam && nextParam.startsWith("/")) {
          navigate(nextParam, { replace: true });
        } else {
          navigate("/my-tournaments", { replace: true });
        }
      } else {
        const res = await apiFetch("/api/auth/register/", {
          method: "POST",
          body: JSON.stringify({ username, email, password }),
          toastOnError: false,
        });

        const data = await res.json().catch(() => ({}));

        if (!res.ok) {
          setError(pickFirstError(data) || "Błąd rejestracji. Sprawdź dane i spróbuj ponownie.");
          return;
        }

        setPassword("");
        setSuccess("Konto utworzone. Możesz się teraz zalogować.");
        goLogin();
      }
    } catch {
      setError("Brak połączenia z serwerem. Spróbuj ponownie.");
    } finally {
      setLoading(false);
    }
  };

  const inputBase = cn(
    "pl-10 pr-3 py-2.5",
    "rounded-2xl bg-white/[0.04]",
    "text-white placeholder:text-slate-500"
  );

  return (
    <div className="mx-auto max-w-md py-8 sm:py-10">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
      >
        <Card className="p-6 sm:p-7">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <h1 className="mt-1 text-2xl font-semibold text-white">
                {mode === "login" ? "Logowanie" : "Rejestracja"}
              </h1>
              <div className="mt-2 break-words text-sm leading-relaxed text-slate-300">
                {mode === "login"
                  ? "Zaloguj się, aby zarządzać turniejami lub dołączyć jako zawodnik, jeśli organizator włączył dołączanie."
                  : "Załóż konto, aby tworzyć turnieje lub dołączać do rozgrywek."}
              </div>
            </div>

            <div className="hidden h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/[0.06] sm:grid">
              {mode === "login" ? (
                <LogIn className="h-5 w-5 text-white/90" />
              ) : (
                <UserPlus className="h-5 w-5 text-white/90" />
              )}
            </div>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-2 rounded-2xl border border-white/10 bg-white/[0.04] p-1">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={goLogin}
              className={cn(
                "rounded-xl px-3 py-2 text-sm font-semibold",
                mode === "login"
                  ? "bg-white/10 text-white shadow-[0_1px_0_rgba(255,255,255,0.06)_inset]"
                  : "text-slate-300 hover:bg-white/5 hover:text-white"
              )}
            >
              Logowanie
            </Button>

            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={goRegister}
              className={cn(
                "rounded-xl px-3 py-2 text-sm font-semibold",
                mode === "register"
                  ? "bg-white/10 text-white shadow-[0_1px_0_rgba(255,255,255,0.06)_inset]"
                  : "text-slate-300 hover:bg-white/5 hover:text-white"
              )}
            >
              Rejestracja
            </Button>
          </div>

          {error || success ? (
            <div className="mt-4 space-y-2">
              {error ? <InlineAlert variant="error">{error}</InlineAlert> : null}
              {success ? <InlineAlert variant="success">{success}</InlineAlert> : null}
            </div>
          ) : null}

          <form onSubmit={submit} className="mt-5 space-y-4">
            <div>
              <label htmlFor="login_username" className="text-sm font-medium text-slate-200">
                Login
              </label>
              <div className="relative mt-2">
                <User
                  className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                  aria-hidden="true"
                />
                <Input
                  id="login_username"
                  className={inputBase}
                  value={username}
                  required
                  autoComplete="username"
                  placeholder="np. nazwa_użytkownika"
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
            </div>

            {mode === "register" ? (
              <div>
                <label htmlFor="login_email" className="text-sm font-medium text-slate-200">
                  Email
                </label>
                <div className="relative mt-2">
                  <Mail
                    className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                    aria-hidden="true"
                  />
                  <Input
                    id="login_email"
                    type="email"
                    className={inputBase}
                    value={email}
                    required
                    autoComplete="email"
                    placeholder="np. user@example.com"
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>
            ) : null}

            <div>
              <label htmlFor="login_password" className="text-sm font-medium text-slate-200">
                Hasło
              </label>
              <div className="relative mt-2">
                <Lock
                  className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                  aria-hidden="true"
                />
                <Input
                  id="login_password"
                  type={showPassword ? "text" : "password"}
                  className={cn(inputBase, "pr-10")}
                  value={password}
                  required
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                  placeholder="••••••••"
                  onChange={(e) => setPassword(e.target.value)}
                />

                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowPassword((v) => !v)}
                  className={cn(
                    "absolute right-2 top-1/2 h-8 min-h-0 -translate-y-1/2 rounded-xl p-2",
                    "text-slate-300 hover:bg-white/5 hover:text-white"
                  )}
                  aria-label={showPassword ? "Ukryj hasło" : "Pokaż hasło"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="pt-2">
              <Button
                type="submit"
                variant={mode === "login" ? "secondary" : "primary"}
                className="w-full justify-center"
                disabled={loading}
                leftIcon={
                  loading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : mode === "login" ? (
                    <LogIn className="h-4 w-4" />
                  ) : (
                    <UserPlus className="h-4 w-4" />
                  )
                }
              >
                {loading ? "Przetwarzanie..." : mode === "login" ? "Zaloguj" : "Zarejestruj"}
              </Button>
            </div>
          </form>

          <div className="mt-5 flex items-center justify-between gap-3">
            {mode === "login" ? (
              <Link to="/forgot-password" className="text-sm text-slate-300 transition hover:text-white">
                Nie pamiętasz hasła?
              </Link>
            ) : (
              <span className="text-sm text-slate-400">
                Masz już konto?{" "}
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={goLogin}
                  className="h-auto min-h-0 p-0 text-slate-200 underline underline-offset-4 hover:bg-transparent hover:text-white"
                >
                  Zaloguj się
                </Button>
              </span>
            )}

            {mode === "login" ? (
              <span className="text-sm text-slate-400">
                Nie masz konta?{" "}
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={goRegister}
                  className="h-auto min-h-0 p-0 text-slate-200 underline underline-offset-4 hover:bg-transparent hover:text-white"
                >
                  Zarejestruj się
                </Button>
              </span>
            ) : (
              <span className="text-sm text-slate-400">Po rejestracji wrócisz do logowania.</span>
            )}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}