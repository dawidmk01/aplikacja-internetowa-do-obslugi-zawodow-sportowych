# backend/tournaments/views/standings.py
# Plik udostępnia dane tabeli i drabinki dla widoku klasyfikacji turnieju.

from __future__ import annotations

from django.shortcuts import get_object_or_404

from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from tournaments.models import Stage, Tournament
from tournaments.services.standings.compute import compute_stage_standings
from tournaments.services.standings.knockout_bracket import get_knockout_bracket
from tournaments.services.standings.types import StandingRow
from tournaments.views._helpers import public_access_or_403


class TournamentStandingsView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk: int):
        tournament = get_object_or_404(Tournament, pk=pk)

        denied = public_access_or_403(request, tournament)
        if denied is not None:
            return denied

        fmt = tournament.tournament_format
        discipline = (getattr(tournament, "discipline", "") or "").lower()
        result_mode = getattr(tournament, "result_mode", Tournament.ResultMode.SCORE)
        result_config = dict(getattr(tournament, "result_config", None) or {})
        format_config = dict(getattr(tournament, "format_config", None) or {})
        competition_model = getattr(tournament, "competition_model", None)

        meta = {
            "discipline": discipline,
            "competition_type": tournament.competition_type,
            "competition_model": competition_model,
            "tournament_format": fmt,
            "result_mode": result_mode,
            "table_schema": self._detect_table_schema(
                discipline=discipline,
                result_mode=result_mode,
                competition_model=competition_model,
                result_config=result_config,
            ),
        }

        response_data: dict = {"meta": meta}

        if discipline == Tournament.Discipline.CUSTOM:
            custom_mode = self._detect_custom_table_mode(
                competition_model=competition_model,
                result_config=result_config,
            )
            value_kind = self._detect_custom_value_kind(
                competition_model=competition_model,
                result_config=result_config,
            )

            response_data["meta"].update(
                {
                    "custom_discipline_name": tournament.custom_discipline_name,
                    "custom_mode": custom_mode,
                    "custom_value_kind": value_kind,
                    "result_config": result_config,
                    "format_config": format_config,
                    "shows_points_table": custom_mode == "HEAD_TO_HEAD_POINTS",
                    "shows_result_ranking": custom_mode in (
                        "HEAD_TO_HEAD_MEASURED",
                        "MASS_START_MEASURED",
                    ),
                }
            )

        if discipline == Tournament.Discipline.TENNIS:
            response_data["meta"]["tennis_points_mode"] = (
                format_config.get("tennis_points_mode") or "NONE"
            )

        if fmt == Tournament.TournamentFormat.LEAGUE:
            stage = tournament.stages.filter(stage_type=Stage.StageType.LEAGUE).first()
            if stage:
                table = compute_stage_standings(tournament, stage)
                response_data["table"] = [
                    self._serialize_row(
                        row=row,
                        discipline=discipline,
                        result_mode=result_mode,
                        competition_model=competition_model,
                        result_config=result_config,
                    )
                    for row in table
                ]

        elif fmt == Tournament.TournamentFormat.MIXED:
            stage = tournament.stages.filter(stage_type=Stage.StageType.GROUP).first()
            if stage:
                groups_payload = []
                groups = stage.groups.all().order_by("name")

                for group in groups:
                    table = compute_stage_standings(tournament, stage, group=group)
                    groups_payload.append(
                        {
                            "group_id": group.id,
                            "group_name": group.name,
                            "table": [
                                self._serialize_row(
                                    row=row,
                                    discipline=discipline,
                                    result_mode=result_mode,
                                    competition_model=competition_model,
                                    result_config=result_config,
                                )
                                for row in table
                            ],
                        }
                    )

                response_data["groups"] = groups_payload

        if fmt in (Tournament.TournamentFormat.CUP, Tournament.TournamentFormat.MIXED):
            bracket_data = get_knockout_bracket(tournament)
            if bracket_data and bracket_data.get("rounds"):
                response_data["bracket"] = bracket_data

        return Response(response_data, status=status.HTTP_200_OK)

    @staticmethod
    def _detect_table_schema(
        *,
        discipline: str,
        result_mode: str,
        competition_model: str | None,
        result_config: dict,
    ) -> str:
        if discipline == Tournament.Discipline.TENNIS:
            return "TENNIS"

        if result_mode != Tournament.ResultMode.CUSTOM:
            return "DEFAULT"

        custom_mode = TournamentStandingsView._detect_custom_table_mode(
            competition_model=competition_model,
            result_config=result_config,
        )

        if custom_mode == "HEAD_TO_HEAD_POINTS":
            return "CUSTOM_POINTS"
        if custom_mode == "HEAD_TO_HEAD_MEASURED":
            return "CUSTOM_MEASURED_HEAD_TO_HEAD"
        if custom_mode == "MASS_START_MEASURED":
            return "CUSTOM_MEASURED_MASS_START"
        return "CUSTOM"

    @staticmethod
    def _detect_custom_table_mode(*, competition_model: str | None, result_config: dict) -> str:
        if competition_model == Tournament.CompetitionModel.HEAD_TO_HEAD:
            head_to_head_mode = (result_config.get("head_to_head_mode") or "POINTS_TABLE").upper()
            if head_to_head_mode == "MEASURED_RESULT":
                return "HEAD_TO_HEAD_MEASURED"
            return "HEAD_TO_HEAD_POINTS"
        return "MASS_START_MEASURED"

    @staticmethod
    def _detect_custom_value_kind(*, competition_model: str | None, result_config: dict) -> str | None:
        if competition_model == Tournament.CompetitionModel.HEAD_TO_HEAD:
            head_to_head_mode = (result_config.get("head_to_head_mode") or "POINTS_TABLE").upper()
            if head_to_head_mode != "MEASURED_RESULT":
                return None
            return (result_config.get("measured_value_kind") or "NUMBER").upper()
        return (result_config.get("mass_start_value_kind") or "TIME").upper()

    @staticmethod
    def _serialize_row(
        *,
        row: StandingRow,
        discipline: str,
        result_mode: str,
        competition_model: str | None,
        result_config: dict,
    ) -> dict:
        base = {
            "team_id": row.team_id,
            "team_name": row.team_name,
            "played": row.played,
            "wins": row.wins,
            "draws": row.draws,
            "losses": row.losses,
            "points": row.points,
            "goals_for": row.goals_for,
            "goals_against": row.goals_against,
            "goal_difference": row.goal_difference,
            "games_for": getattr(row, "games_for", 0),
            "games_against": getattr(row, "games_against", 0),
            "games_difference": getattr(row, "games_difference", 0),
            "rank": getattr(row, "rank", None),
        }

        if discipline == Tournament.Discipline.TENNIS:
            base.update(
                {
                    "sets_for": row.goals_for,
                    "sets_against": row.goals_against,
                    "sets_diff": row.goal_difference,
                    "games_for": getattr(row, "games_for", 0),
                    "games_against": getattr(row, "games_against", 0),
                    "games_diff": getattr(row, "games_difference", 0),
                }
            )

        if result_mode == Tournament.ResultMode.CUSTOM:
            custom_mode = TournamentStandingsView._detect_custom_table_mode(
                competition_model=competition_model,
                result_config=result_config,
            )
            custom_value_kind = TournamentStandingsView._detect_custom_value_kind(
                competition_model=competition_model,
                result_config=result_config,
            )

            base.update(
                {
                    "is_custom_result": True,
                    "custom_mode": custom_mode,
                    "custom_value_kind": custom_value_kind,
                    "custom_result_numeric": getattr(row, "custom_result_numeric", None),
                    "custom_result_time_ms": getattr(row, "custom_result_time_ms", None),
                    "custom_result_display": getattr(row, "custom_result_display", None),
                }
            )

            if custom_value_kind == "PLACE":
                base["custom_result_place"] = getattr(row, "custom_result_place", None)

        return base
